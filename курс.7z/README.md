

## npm run dev - запуск сервера

## npm start - запуск клиента
